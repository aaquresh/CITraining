#
# Cookbook Name:: class-cookbook
# Recipe:: default
#
# Copyright 2014, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
directory "/tmp/presentation" do
  owner "root"
  mode 0777
  action :create
end
# the end
