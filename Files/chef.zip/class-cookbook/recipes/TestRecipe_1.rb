user "create_user" do
  action :create
  #password "testpasswd"
end

directory "/root/DirectorCreatedByChefTest" do
    owner "root"
    group "root"
    mode 777
    action :create
end

yum_package "git"

deploy "KylesTestApp" do
    action "deploy"
    repo "https://github.com/frosario/vagrant"
end

